Install Terraform
Install Ansible
Then execute the ./deploy.sh it will create the entire infrastructure using playbook and terraform components will de deployed.

